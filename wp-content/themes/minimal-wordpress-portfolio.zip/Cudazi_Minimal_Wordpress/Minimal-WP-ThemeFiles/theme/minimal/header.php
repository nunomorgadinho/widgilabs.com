<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<title><?php bloginfo('name'); ?><?php wp_title(' - ', true, 'left'); ?></title>
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
    <?php if(get_option("menuwidth")) { ?><style type="text/css" media="screen">.menu UL{ width:<?php echo get_option("menuwidth"); ?>; }</style><?php }?>
    <?php if(get_option("color_main")) { ?><style type="text/css" media="screen">h3, a, .tagline p a, UL.clean LI a:hover, UL.large LI a:hover span{ color:<?php echo get_option("color_main"); ?>; }</style><?php }?>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/general.js"></script>
	<?php wp_head(); ?>
</head>
<body>
<div id="outer">
    <div class="contentwidth main">
<div class="logo">
	<?php
		$logo_html = get_option("logo_html");
		if($logo_html)
		{
			echo "<h1><a href='". get_bloginfo('url') ."' class='custom'><img src='". $logo_html . "' alt='".get_bloginfo("name")."' /></a></h1>";
		}else{
			echo "<h1><a href='". get_bloginfo('url') ."'>". get_bloginfo('name'). "</a></h1>";
		}
	?>
	
</div><!-- end logo -->

<div class="menu">
	<ul class="clearfix">
		<?php 
			$menu_exclude = get_option("menu_exclude");
			if($menu_exclude)
			{
				$exclude = "&exclude=".$menu_exclude;
			}
			wp_list_pages('title_li=&depth=1'.$exclude); 
		?>
	</ul>
</div><!-- end menu -->

<?php display_tagline($post->ID); ?>
