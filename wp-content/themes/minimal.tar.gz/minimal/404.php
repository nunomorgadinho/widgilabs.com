<?php
get_header();
?>
<div class="clearfix">
	<h2>Not Found!</h2>
</div>
<?php get_sidebar(); ?>

<?php get_footer(); ?>